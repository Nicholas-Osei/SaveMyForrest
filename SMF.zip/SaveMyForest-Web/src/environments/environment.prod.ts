export const environment = {
    production: true,
  firebase: {
    projectId: 'save-my-forest',
    appId: '1:857573165628:web:880420a3d5b647f0299139',
    databaseURL: 'https://save-my-forest-default-rtdb.europe-west1.firebasedatabase.app',
    storageBucket: 'save-my-forest.appspot.com',
    locationId: 'europe-west',
    apiKey: 'AIzaSyA3to5nwF3Khnz_t2oXjyAJGFr0h746ZKY',
    authDomain: 'save-my-forest.firebaseapp.com',
    messagingSenderId: '857573165628',
  }
};
