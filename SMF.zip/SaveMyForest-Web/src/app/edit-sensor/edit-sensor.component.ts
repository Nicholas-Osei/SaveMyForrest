import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-sensor',
  templateUrl: './edit-sensor.component.html',
  styleUrls: ['./edit-sensor.component.scss']
})
export class EditSensorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
