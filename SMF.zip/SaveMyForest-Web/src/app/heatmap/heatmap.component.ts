import { Component, OnInit, AfterViewInit, Renderer2 } from '@angular/core';

declare function map2(lat: number, lon: number): void;
declare function heat(color: number): void;
declare function build(sensor: any): void;
declare function update(): void;
declare function update2(): void;
import { AngularFireDatabase, AngularFireList } from '@angular/fire/compat/database';
import { Router } from '@angular/router';
import { map } from '@firebase/util';
import { FirebaseServiceService } from '../Services/firebase-service.service';

@Component({
  selector: 'app-heatmap',
  templateUrl: './heatmap.component.html',
  styleUrls: ['./heatmap.component.scss']
})
export class HeatmapComponent implements OnInit {


  Sensors: any = []
  Ingelogd: any
  condition: boolean = true;
  constructor(public db: AngularFireDatabase, public dbService: FirebaseServiceService, public router: Router, private render: Renderer2) {

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(this.showPosition, this.showError);
    }

  }

  ngAfterViewInit() {
    console.log('test');
    const classArr: any = document.querySelectorAll('.switch-input');
    classArr.forEach((b: any) => {
      this.render.listen(b, 'click', (target) => {
        console.log('clicked', b.checked);
        if (b.checked) {
          console.log("update")
          update();
          this.ngOnInit();
        }
        else {
          update2();
          this.ngOnInit();
        }

      });
    });
  }


  ngOnInit(): void {
    this.Ingelogd = localStorage.getItem("loggedIn")
    if (this.Ingelogd) {
      this.dbService.Username = localStorage.getItem('UName')
      const ref = this.db.list('/user/' + this.dbService.Username)
      ref.valueChanges().subscribe((data) => {
        this.Sensors = data;
        if (this.condition) {
          build(this.Sensors)
          this.condition = false;
        }
        heat(this.Sensors)

      })
      build(this.Sensors)
      heat(this.Sensors)

    } else {

      this.router.navigate(['/login'])
    }

  }
  getLocation() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(this.showPosition);
    }
  }
  showPosition(position: any) {
    map2(position.coords.latitude, position.coords.longitude);
  }

  showError(error: any) {
    map2(50.5010789, 4.4764595);
  }
}
