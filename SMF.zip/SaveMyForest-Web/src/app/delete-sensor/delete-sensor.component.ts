import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-delete-sensor',
  templateUrl: './delete-sensor.component.html',
  styleUrls: ['./delete-sensor.component.scss']
})
export class DeleteSensorComponent implements OnInit {
   x = window.matchMedia("(max-width: 600px)")
  // public dialogRef: MatDialogRef<DeleteSensorComponent>;
  constructor(public dialogRef: MatDialogRef<DeleteSensorComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }


  ngOnInit(): void {
    smaller(this.x);
    this.x.addEventListener("change",smaller)
  }



  Close() {
    this.dialogRef.close(false)

  }

}
function smaller(x: { matches: any; }) {
  if (x.matches) { // If media query matches
    document.getElementById("popup")!.innerText="delete this sensor";
  } 
}

