import { Component, OnInit } from '@angular/core';
import { NgModule } from '@angular/core';
import { AngularFireDatabase } from '@angular/fire/compat/database';
import { Router, RouterLink } from '@angular/router';
import { FirebaseServiceService } from '../Services/firebase-service.service';
import { MessagingService } from '../Services/messaging.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  register = false


  constructor(private router: Router, private firebaseService: FirebaseServiceService, public db: AngularFireDatabase,) {
    // firebaseService.logout()
  }

  ngOnInit(): void {
    if (localStorage.getItem('user') !== null) {
      this.firebaseService.isLoggedIn = true
    }
    else {
      this.firebaseService.isLoggedIn = false
    }
  }



  checkUserCredential(form: any) {
    //check if user credentials are valid
    this.firebaseService.signIn(form.value.email, form.value.password).
      //if valid navigate to home 
      then(res => { this.router.navigate(['/home']), console.log('logedin'), console.log(this.firebaseService.TelefoonNummer); console.log(this.firebaseService.isLoggedIn); localStorage.setItem("loggedIn", JSON.stringify(this.firebaseService.isLoggedIn)); localStorage.setItem("Name", this.firebaseService.Username) }).catch(
        res => alert("Email or Password is wrong")
      )


  }
  SignUP(form: any) {
    //create user
    this.firebaseService.signUp(form.value.email, form.value.password, form.value.telnumber).
      //send to login page 
      then(res => {
        console.log('nummber', this.firebaseService.TelefoonNummer)
        localStorage.setItem('number', this.firebaseService.TelefoonNummer)
        this.firebaseService.Username = form.value.username;
        localStorage.setItem('Profilename', this.firebaseService.Username)
        this.db.database.ref('user/' + form.value.username).set(
          {
            "Sensor1": {
              "hum": 0,
              "temp": 0
            },
            "Sensor2": {
              "hum": 0,
              "temp": 0
            },
            "Sensor3": {
              "hum": 3,
              "temp": 7
            }
          }
        )
      }).
      then(res => { alert("Account created SUCCESFULLY, please Login"); this.GoToSignIn(); }).
      catch(res => alert(res))

  }

  MakeRegisterTrue() {
    this.register = true
  }
  GoToSignIn() {
    this.register = false
  }


}
