import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ForgroundNotificationConfirmdialogComponent } from '../forground-notification-confirmdialog/forground-notification-confirmdialog.component';
import { MessagingService } from './messaging.service';

@Injectable({
  providedIn: 'root'
})
export class NotificationforgroundService {

  bericht: any
  constructor(private dialog: MatDialog, public ms: MessagingService) { }

  openConfirmNotificationdialog(msg: string) {
    return this.dialog.open(ForgroundNotificationConfirmdialogComponent, {
      width: '390px',
      panelClass: 'confirm-dialog-container1',
      disableClose: true,
      data: {
        message: msg
      }
    })
  }

  async start() {
    console.log(this.ms.cToken)
    this.bericht = {
      notification: {
        title: "HELLO USER",
        body: "This is just a test for the notification"
      },
      to: this.ms.cToken
    }
    this.ms.SendNotificationViaPost(this.bericht).subscribe(r => console.log('message', r))
  }


}
