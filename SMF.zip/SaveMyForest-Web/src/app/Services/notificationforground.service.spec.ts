import { TestBed } from '@angular/core/testing';

import { NotificationforgroundService } from './notificationforground.service';

describe('NotificationforgroundService', () => {
  let service: NotificationforgroundService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NotificationforgroundService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
