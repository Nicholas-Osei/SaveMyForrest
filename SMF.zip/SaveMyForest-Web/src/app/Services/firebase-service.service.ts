import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { AngularFireDatabase, AngularFireList } from '@angular/fire/compat/database';


@Injectable({
  providedIn: 'root'
})
export class FirebaseServiceService {
  Email = ""
  Username: any;
  isLoggedIn = false
  fire = false
  Sensors: any = []
  tutorialsRef: AngularFireList<any[]> | undefined;
  TelefoonNummer: any
  eh: any;
  ProfileName = ''
  em: any
  pas: any

  constructor(public fireAuth: AngularFireAuth, public db: AngularFireDatabase) {

  }

  async signIn(email: string, password: string) {
    await this.fireAuth.setPersistence('local').then(() =>
      this.fireAuth.signInWithEmailAndPassword(email, password).then
        (res => {
          this.Email = email
          this.isLoggedIn = true
          this.em = email
          this.pas = password
          // this.eh =res.user
          this.Username = this.Email.substring(0, this.Email.indexOf('@'))
          localStorage.setItem('user', JSON.stringify(res.user))
          localStorage.setItem('Profilename', this.Username)
          // this.fireAuth.currentUser.then(lol => lol?.updatePhoneNumber())
          // res.user?.updateProfile({
          //   displayName: this.TelefoonNummer
          // })
          localStorage.setItem('UName', this.Username)
          this.TelefoonNummer = res.user?.displayName
          localStorage.setItem('number', this.TelefoonNummer)
          console.log(res.user)
          console.log(this.TelefoonNummer)


        }))



  }

  async signUp(email: string, password: string, tel: string) {
    await this.fireAuth.createUserWithEmailAndPassword(email, password).then
      (res => {
        this.isLoggedIn = true
        localStorage.setItem('user', JSON.stringify(res.user))
        res.user?.updateProfile({
          displayName: tel
        })
      })
  }



  logout() {
    this.fireAuth.signOut();
    localStorage.removeItem('user')
  }
}
