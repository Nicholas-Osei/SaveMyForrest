import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AngularFireMessaging } from '@angular/fire/compat/messaging';
@Injectable({
  providedIn: 'root'
})
export class MessagingService {



  cToken: any;
  bericht: any

  constructor(private angularFireMessaging: AngularFireMessaging, public _http: HttpClient) {

    // this.angularFireMessaging.messages.subscribe((_messaging) => {
    //   _messaging. = _messaging.onMessage.bind(_messaging);
    //   _messaging.onTokenRefresh = _messaging.onTokenRefresh.bind(_messaging);

    // })

  }

  async requestPermission() {
    this.angularFireMessaging.requestToken.subscribe(
      (token: any) => {
        console.log(token);
        this.cToken = token;
        console.log("c", this.cToken);
      },
      (err: any) => {
        console.error('Unable to get permission to notify.', err);
      }
    );

  }

  ForegroundMessage() {
    this.angularFireMessaging.messages
      .subscribe((message) => { console.log(message); });
  }
  deleteToken() {
    this.angularFireMessaging.deleteToken(this.cToken)
    this.angularFireMessaging.getToken
      .subscribe(
        (token) => { console.log('Token deleted!'); },
      );
  }
  SendNotificationViaPost(msg: any) {
    const httpHeaders = new HttpHeaders({
      'content-type': 'application/json',
      'Authorization': 'key=AAAAx6tYCjw:APA91bELK-XVMEOiu40_iRw9-LXgVo27lxtJ3fyxZmrC4783aGSa9o_A6xeTIsc-1o0FwmJCdNUQPhh28eG2QHr9k6KWlVuwvUFjOuJdMRP8RMvGcH1ZCo75_--G2Zng2Gb8TVYlARgu'
    });
    console.log(httpHeaders.get)
    return this._http.post("https://fcm.googleapis.com/fcm/send", msg, { headers: httpHeaders })
  }

  Sms(msg: any) {
    const httpHeaders = new HttpHeaders({
      'content-type': 'application/x-www-form-urlencoded',
      'Authorization': 'Basic ' + btoa('AC69789993005de1087f7670e495e51518:899d588a7ea86431139c84f26d9eed0a')
    });
    return this._http.post('https://api.twilio.com/2010-04-01/Accounts/AC69789993005de1087f7670e495e51518/Messages.json', msg, { headers: httpHeaders })
  }

}
