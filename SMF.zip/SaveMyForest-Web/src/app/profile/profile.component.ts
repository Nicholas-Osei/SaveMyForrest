import { Component, Inject, OnInit } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { FirebaseServiceService } from '../Services/firebase-service.service';


@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {

  ProfileName: any
  NummberOfSensors: any
  TelefoonNummer: any
  user: any
  numberChange = false
  telnummer: string = ''
  constructor(public FireService: FirebaseServiceService, private router: Router, private dialog: MatDialog, public fireAuth: AngularFireAuth, public dialogRef: MatDialogRef<ProfileComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }


  ngOnInit(): void {
    this.ProfileName = localStorage.getItem("Profilename")
    this.NummberOfSensors = localStorage.getItem("NummberOfSensors")
    // this.TelefoonNummer = localStorage.getItem("number")?.slice(1, 12)
    this.TelefoonNummer = localStorage.getItem("number")

  }

  SignOut() {
    this.FireService.logout()
    this.router.navigate(['/login'])
    localStorage.clear()
  }


  Close() {
    this.dialogRef.close()

  }
  ChangeNumber() {
    console.log("nummbers")
    this.numberChange = true

  }

  ChangeTelefoonNummer(form: { value: { telnumber: any; }; }) {
    console.log(form.value.telnumber)
    this.telnummer = form.value.telnumber
    this.fireAuth.currentUser.then(res => res?.updateProfile(
      {
        displayName: this.telnummer
      }
    ).then(() => { console.log(res.displayName); localStorage.setItem("number", this.telnummer); this.ngOnInit() }))
    this.numberChange = false

  }


}

