import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import {MatPaginatorModule} from '@angular/material/paginator';
import {MatTableModule} from '@angular/material/table'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { SensorsComponent } from './sensors/sensors.component';
import { HeatmapComponent } from './heatmap/heatmap.component';
import { RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { AddSensorComponent } from './add-sensor/add-sensor.component';
import { FormsModule } from '@angular/forms';
import { EditSensorComponent } from './edit-sensor/edit-sensor.component';
import { AngularFireModule } from '@angular/fire/compat';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatSliderModule } from '@angular/material/slider';
import { ProfileComponent } from './profile/profile.component';
import { MatDialogModule } from '@angular/material/dialog';
import { DeleteSensorComponent } from './delete-sensor/delete-sensor.component';
import { MatIconModule } from '@angular/material/icon';
import { AngularFireMessagingModule } from '@angular/fire/compat/messaging';
import { ForgroundNotificationConfirmdialogComponent } from './forground-notification-confirmdialog/forground-notification-confirmdialog.component';
import { HttpClientModule } from '@angular/common/http';
import { initializeApp, provideFirebaseApp } from '@angular/fire/app';
import { environment } from '../environments/environment';
import { provideDatabase, getDatabase } from '@angular/fire/database';
import { AgmCoreModule } from '@agm/core';
import { NgChartsModule } from 'ng2-charts';
import { MatGridListModule } from '@angular/material/grid-list';



@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    NavBarComponent,
    SensorsComponent,
    HeatmapComponent,
    LoginComponent,
    AddSensorComponent,
    EditSensorComponent,
    ProfileComponent,
    DeleteSensorComponent,
    ForgroundNotificationConfirmdialogComponent
  ],
    imports: [
        BrowserModule,
        AppRoutingModule,
        FormsModule,
        MatPaginatorModule,
        MatSliderModule,
        MatDialogModule,
        MatIconModule,

        MatTableModule,
        AngularFireMessagingModule,
        HttpClientModule,
        AngularFireModule.initializeApp(environment.firebase),
        AgmCoreModule.forRoot({
            apiKey: 'AIzaSyBzp6ORmuQUdqb-RdpG9f90TBihXuAMbkc'
        }),
        RouterModule.forRoot([
            { path: "home", component: HomeComponent },
            { path: "sensors", component: SensorsComponent },
            { path: "heatmap", component: HeatmapComponent },
            { path: "login", component: LoginComponent },
            { path: "addsensor", component: AddSensorComponent },
            { path: "", redirectTo: "login", pathMatch: 'full' },

        ], { useHash: true }),
        BrowserAnimationsModule,
        provideFirebaseApp(() => initializeApp(environment.firebase)),
        provideDatabase(() => getDatabase()),
        NgChartsModule,
        MatGridListModule,
    ],
  providers: [],
  bootstrap: [AppComponent]
})

export class AppModule { }
