import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MessagingService } from '../Services/messaging.service';

@Component({
  selector: 'app-forground-notification-confirmdialog',
  templateUrl: './forground-notification-confirmdialog.component.html',
  styleUrls: ['./forground-notification-confirmdialog.component.scss']
})
export class ForgroundNotificationConfirmdialogComponent implements OnInit {

  bericht: any
  constructor(@Inject(MAT_DIALOG_DATA) public data: any, public dialogref: MatDialogRef<ForgroundNotificationConfirmdialogComponent>, public ms: MessagingService) { }

  ngOnInit(): void {
  }

  closeDialog() {
    this.dialogref.close(false)
  }


}
