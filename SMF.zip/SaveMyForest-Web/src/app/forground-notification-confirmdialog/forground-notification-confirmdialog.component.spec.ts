import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForgroundNotificationConfirmdialogComponent } from './forground-notification-confirmdialog.component';

describe('ForgroundNotificationConfirmdialogComponent', () => {
  let component: ForgroundNotificationConfirmdialogComponent;
  let fixture: ComponentFixture<ForgroundNotificationConfirmdialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForgroundNotificationConfirmdialogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForgroundNotificationConfirmdialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
