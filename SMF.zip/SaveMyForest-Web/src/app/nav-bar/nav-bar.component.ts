import { Component, OnInit } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { MatDialogConfig } from '@angular/material/dialog';
import { ProfileComponent } from '../profile/profile.component';
import { FirebaseServiceService } from '../Services/firebase-service.service';


@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.scss']
})
export class NavBarComponent implements OnInit {
x:any;

t:any;
  items: any
  constructor(public FireService: FirebaseServiceService, private router: Router, private dialog: MatDialog) { }

  ngOnInit(): void {
    this.items = [
      { label: 'HOME', routerLink: "/home" },
      { label: 'SENSORS', routerLink: "/sensors" },
      { label: 'HEATMAP', routerLink: "/heatmap" },
    ];
  }

  OpenProfile() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true
    dialogConfig.autoFocus = true
    dialogConfig.width = "30%"
    this.dialog.open(ProfileComponent, dialogConfig)
  }

  SignOut() {
    this.FireService.logout()
    this.router.navigate(['/login'])
    localStorage.clear()
  }
   myFunction() {
    this.t = document.getElementById("titel");
    
     this.x = document.getElementById("myLinks");
    if (this.x.style.display === "block") {
      this.t.style.display = "inline";
      this.x.style.display = "none";
    } else {
      this.x.style.display = "block";
      this.t.style.display = "none";
    }

  }
}
