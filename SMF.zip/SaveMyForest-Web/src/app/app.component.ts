import { Component, OnInit } from '@angular/core';
import { AngularFireDatabase } from '@angular/fire/compat/database';
import { FirebaseServiceService } from './Services/firebase-service.service';
import { MessagingService } from './Services/messaging.service';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { Router, RouterLink } from '@angular/router';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'SaveMyForest-Web';
  ToNumber = '+32484855456'
  FromNumber = '+19283962669'
  body = "Er is Brand! Temperatuur is nu "
  Sensors: any
  name = 'hahaha'
  currentUser: any
  Ingelogd: any

  /**
   * 
   *
   */
  constructor(public msg: MessagingService, public fire: FirebaseServiceService, public db: AngularFireDatabase, public auth: AngularFireAuth, public router: Router) {

    console.log('from contructor')
    console.log(this.fire.TelefoonNummer)
    console.log(this.fire.Username)
    console.log(this.fire.em)
    this.Ingelogd = localStorage.getItem("loggedIn")
    console.log(this.Ingelogd)

    if (this.Ingelogd) {
      this.fire.Username = localStorage.getItem('UName')
      const ref = this.db.list('/user/' + this.fire.Username)
      ref.valueChanges().subscribe((data) => {
        this.Sensors = data;
        // this.fire.Sensors = data;
        localStorage.setItem("NummberOfSensors", JSON.stringify(data.length))
        console.log(this.Sensors)
      })
    }
    else {
      this.router.navigate(['/login'])
    }
    // if (this.fire.em) {
    //   console.log('best')
    //   this.fire.signIn(this.fire.em, this.fire.pas).then(() => console.log('ingelogd')).then(() => {
    //     const ref = this.db.list('/user/' + this.fire.Username)
    //     ref.valueChanges().subscribe((data) => {
    //       this.Sensors = data;
    //       // this.fire.Sensors = data;
    //       console.log(this.Sensors)
    //     })
    //   })
    // }
  }

  ngOnInit() {

  }





  sendSms() {
    // let body = "From=+19283962669&To=+32484855456&Body=this is from angular Nicholas"
    // let body = "From=" + this.FromNumber + "&To=" + this.ToNumber + "&Body=" + this.body
    this.fire.TelefoonNummer = localStorage.getItem("number")
    let body = "From=" + this.FromNumber + "&To=" + this.fire.TelefoonNummer + "&Body=" + this.body
    this.msg.Sms(body).subscribe(s => {
      console.log("sent")
    })
    console.log(this.fire.TelefoonNummer)
  }
  waarde = 0
  CheckingFire(first: any, sensor: any) {
    // this.tel++
    if (first != this.waarde && first > this.waarde) {
      //alert('hahha')
      console.log('fire !!')
      this.body = "Er is Brand! " + sensor + " Temperatuur is nu " + first + " °C Klik hierop om hem te bekijken " + "https://savemyforest.azurewebsites.net/#/sensors"
      this.sendSms()
      this.waarde = first
    }

  }
}
