import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FirebaseServiceService } from '../Services/firebase-service.service';

@Component({
  selector: 'app-add-sensor',
  templateUrl: './add-sensor.component.html',
  styleUrls: ['./add-sensor.component.scss']
})
export class AddSensorComponent implements OnInit {

  constructor(private router: Router, private http: HttpClient, private dbService: FirebaseServiceService) {

  }

  ngOnInit(): void {
  }

  AddSensor(serial: string) {
    //voeg serial toe aan sensoren array
    this.http.patch("https://save-my-forest-default-rtdb.europe-west1.firebasedatabase.app/user/" + this.dbService.Username + "/.json",
      {
        "Sensor": {
          "hum": 120,
          "temp": 8
        }
      }).subscribe()


    //redirect to sensors page
    this.router.navigate(['/sensors'])

  }

  Cancel() {
    this.router.navigate(['/sensors'])
  }


}
