
var map, mymap;
var marker;
var circle;
let text = "";
let text2 = "";
let tempchange = [];
let lat = ["51.230088", "51.398197", "51.382183", "51.389941", "51.393285", "51.404442"];
let long = ["4.419894", "4.389457", "4.404700", "4.407723", "4.417756", "4.383714",];
let variabelen = [];
let variabelen2 = [];
let variab;
var popup;
let mapimg = "https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}"
var Radius = 50;
var currentlocation = [];
var currentZoom = 13;

function heat(temp) {
    variab = temp;

    for (i = 1; i <= temp.length; i++) {
        if (tempchange[i] != temp[i - 1].temp) {

            const tempval = temp[i - 1].temp;
            if (tempval >= 50 && tempval < 100) {

                variabelen[i].setStyle({ fillColor: "blue", fillOpacity: 0.6 });
                variabelen2[i].setPopupContent(`<h3> Sensor ${i} </h3><h3>Temp: ${temp[i - 1].temp} </h3>`);

            }
            else if (tempval > 100) {

                variabelen[i].setStyle({ fillColor: "red",fillOpacity: 0.6});
                variabelen2[i].setPopupContent(`<h3> Sensor ${i} </h3><h3>Temp: ${temp[i - 1].temp} </h3>`);

            }
            else if (tempval < 50) {

                variabelen[i].setStyle({ fillColor: "green",fillOpacity: 0.6 });
                variabelen2[i].setPopupContent(`<h3> Sensor ${i} </h3><h3>Temp: ${temp[i - 1].temp} </h3>`);

            }
        }


    }
}

function map2(lan, lon) {
    console.log(currentZoom)
    map = L.map('map').setView([lan, lon], currentZoom);
    currentlocation = [];
    currentlocation.push(lan);
    currentlocation.push(lon);
    mymap = L.tileLayer(mapimg, {
        maxZoom: 18,
        minZoom: 3,
        id: 'mapbox/streets-v11',
        tileSize: 512,
        zoomOffset: -1,
        accessToken: 'pk.eyJ1IjoiYW5kcmVzZGF2YWxvc2MiLCJhIjoiY2tmYWM0ZTZjMHVoMDJ5cXNmbW5kZnlsZSJ9.n1MQi2NwJclJ8pzAws3qrw'
    }).addTo(map);

    document.getElementById("sensor").addEventListener("change", function () {
        currentlocation = [];
        currentlocation.push(lat[this.value - 1]);
        currentlocation.push(long[this.value - 1]);
        map.flyTo([lat[this.value - 1], long[this.value - 1]], 18, {
            animate: true,
            duration: 5
        });
    });

}


function update() {
    map.remove();
    mapimg = 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png';
    map2(currentlocation[0], currentlocation[1]);

}
function update2() {
    map.remove();
    mapimg = 'https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}';
    map2(currentlocation[0], currentlocation[1]);
}



function build(sensor) {
    variabelen = [];
    variabelen2 = [];
    for (i = 1; i <= sensor.length; i++) {
        text = "marker" + i;
        text2 = "circle" + i;
        variabelen.push(text2);
        variabelen2.push(text);
        variabelen2[i] = L.marker([lat[i - 1], long[i - 1]]).addTo(map).bindPopup('');
        variabelen[i] = L.circle([lat[i - 1], long[i - 1]], {
            color: 'grey',
            radius: Radius,
        }).addTo(map)
    }

    map.on('zoomend', function (e) {
        currentZoom = map.getZoom();
        console.log("Current Zoom" + " " + currentZoom);
        if (currentZoom == 4) {
            Radius = 500000;
        }
        if (currentZoom == 5) {
            Radius = 250000;
        }
        if (currentZoom == 6) {
            Radius = 100000;
        }
        if (currentZoom >= 7) {
            Radius = 30000;
        }
        if (currentZoom == 8) {
            Radius = 10000;
        }
        if (currentZoom == 9) {
            Radius = 8000;
        }
        if (currentZoom == 10) {
            Radius = 5000;
        }
        if (currentZoom == 11) {
            Radius = 2500;
        }
        if (currentZoom == 12) {
            Radius = 1000;
        }
        if (currentZoom == 13) {
            Radius = 500;
        }
        if (currentZoom == 14) {
            Radius = 220;
        }
        if (currentZoom >= 15) {
            Radius = 40;
        }

        variabelen[1].setRadius(Radius)
        variabelen[2].setRadius(Radius)
        variabelen[3].setRadius(Radius)
        variabelen[4].setRadius(Radius)
        variabelen[5].setRadius(Radius)
        variabelen[6].setRadius(Radius)
        console.log(" Radius" + " " + Radius);


    });
}







