importScripts('https://www.gstatic.com/firebasejs/7.6.0/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/7.6.0/firebase-messaging.js');

firebase.initializeApp({
    apiKey: "AIzaSyA3to5nwF3Khnz_t2oXjyAJGFr0h746ZKY",
    authDomain: "save-my-forest.firebaseapp.com",
    projectId: "save-my-forest",
    storageBucket: "save-my-forest.appspot.com",
    messagingSenderId: "857573165628",
    appId: "1:857573165628:web:880420a3d5b647f0299139"
  })

  const messaging = firebase.messaging();